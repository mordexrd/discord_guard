Kurulum: npm install discord.js axios
Çalıştırma: node index.js
Bot tokenını 'BOT_TOKEN' yerine yaz.